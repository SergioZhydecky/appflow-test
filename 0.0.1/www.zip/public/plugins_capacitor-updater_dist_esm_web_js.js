(self["webpackChunkappflow_test"] = self["webpackChunkappflow_test"] || []).push([["plugins_capacitor-updater_dist_esm_web_js"],{

/***/ 7534:
/*!*******************************************************!*\
  !*** ../../plugins/capacitor-updater/dist/esm/web.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CapacitorUpdaterWeb": () => (/* binding */ CapacitorUpdaterWeb)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 4037);

class CapacitorUpdaterWeb extends _capacitor_core__WEBPACK_IMPORTED_MODULE_0__.WebPlugin {
    async download(options) {
        console.log('Cannot download version in web', options);
        return { version: "" };
    }
    async set(options) {
        console.log('Cannot set version in web', options);
    }
    async delete(options) {
        console.log('Cannot delete version in web', options);
    }
    async list() {
        console.log('Cannot list version in web');
        return { versions: [] };
    }
    async reset() {
        console.log('Cannot reset version in web');
    }
    async current() {
        console.log('Cannot get current version in web');
        return { current: 'default' };
    }
}


/***/ })

}]);
//# sourceMappingURL=plugins_capacitor-updater_dist_esm_web_js.js.map